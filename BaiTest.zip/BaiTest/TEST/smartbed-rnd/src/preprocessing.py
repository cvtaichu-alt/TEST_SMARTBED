"""
Data preprocessing module for Smart Bed sensor data
"""

import pandas as pd
import numpy as np
from scipy import signal
from pathlib import Path
from config import SMOOTHING_WINDOW, OUTLIER_THRESHOLD


class DataPreprocessor:
    """Handles data loading, cleaning, and preprocessing"""
    
    def __init__(self, filepath):
        """Initialize preprocessor with data file"""
        self.data = None
        self.filepath = filepath
        
    def load_data(self):
        """Load CSV data"""
        filepath = Path(self.filepath)
        if not filepath.is_absolute():
            filepath = filepath.resolve()
        print(f"Loading data from: {filepath}")
        print(f"Current working directory: {Path.cwd()}")
        try:
            self.data = pd.read_csv(filepath)
            print(f"Data loaded successfully: {len(self.data)} records")
            return self.data
        except Exception as e:
            print(f"Error loading data: {e}")
            return None
    
    def handle_missing_values(self):
        """Handle missing or zero values in sensor data"""
        if self.data is None:
            return None
        
        # Mark hr_bpm = 0.0 as sensor dropout (not interpolate)
        self.data['hr_dropout'] = (self.data['hr_bpm'] == 0.0).astype(int)
        
        # Replace 0.0 heart rate with NaN but keep dropout flag
        self.data['hr_bpm'] = self.data['hr_bpm'].replace(0.0, np.nan)
        # Only interpolate if within reasonable threshold
        self.data['hr_bpm'] = self.data['hr_bpm'].interpolate(method='linear', limit=5)
        
        return self.data
    
    def remove_outliers(self, column, threshold=OUTLIER_THRESHOLD):
        """Remove statistical outliers from a column"""
        if column not in self.data.columns:
            return self.data
        
        mean = self.data[column].mean()
        std = self.data[column].std()
        lower_bound = mean - threshold * std
        upper_bound = mean + threshold * std
        
        # Replace outliers with interpolated values
        mask = (self.data[column] < lower_bound) | (self.data[column] > upper_bound)
        self.data.loc[mask, column] = np.nan
        self.data[column] = self.data[column].interpolate(method='linear')
        
        return self.data
    
    def smooth_signal(self, column, window=SMOOTHING_WINDOW):
        """Apply moving average smoothing to a column"""
        if column not in self.data.columns:
            return self.data
        
        self.data[f'{column}_smooth'] = self.data[column].rolling(
            window=window, center=True
        ).mean()
        
        return self.data
    
    def normalize_column(self, column):
        """Normalize a column to 0-1 range"""
        if column not in self.data.columns:
            return self.data
        
        min_val = self.data[column].min()
        max_val = self.data[column].max()
        
        if max_val == min_val:
            self.data[f'{column}_norm'] = 0
        else:
            self.data[f'{column}_norm'] = (self.data[column] - min_val) / (max_val - min_val)
        
        return self.data
    
    def preprocess(self):
        """Execute full preprocessing pipeline"""
        print("Starting preprocessing...")
        
        self.data = self.load_data()
        if self.data is None:
            print("Preprocessing aborted: data could not be loaded.")
            return None
        
        self.handle_missing_values()
        
        # Remove outliers from sensor columns
        for col in ['loadcell_kg', 'motion_intensity', 'chest_disp', 'hr_bpm', 'spo2']:
            self.remove_outliers(col)
        
        # Smooth signals
        for col in ['chest_disp', 'motion_intensity', 'hr_bpm', 'spo2']:
            self.smooth_signal(col)
        
        # Normalize signals
        for col in ['chest_disp', 'motion_intensity', 'hr_bpm', 'spo2']:
            self.normalize_column(col)
        
        print("Preprocessing completed!")
        return self.data
    
    def get_data(self):
        """Return preprocessed data"""
        return self.data


if __name__ == "__main__":
    from config import DATA_PATH

    preprocessor = DataPreprocessor(DATA_PATH)
    processed_data = preprocessor.preprocess()
    if processed_data is not None:
        print(processed_data.head())
    else:
        print("No data available to display.")
