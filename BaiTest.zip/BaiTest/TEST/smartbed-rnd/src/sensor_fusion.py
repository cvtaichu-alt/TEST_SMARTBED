"""
Sensor fusion module for combining multiple sensors
"""

import numpy as np
import pandas as pd
from scipy import signal
from config import (
    SAMPLING_RATE,
    EMPTY_WEIGHT_THRESHOLD,
    MOTION_STILL_THRESHOLD,
    MOTION_MOVING_THRESHOLD,
    LEAVING_MOTION_THRESHOLD,
)


class SensorFusion:
    """Combines multiple sensor streams for better estimation"""
    
    def __init__(self, data):
        """Initialize with preprocessed data"""
        self.data = data.copy()
        
    def fuse_respiratory_signals(self):
        """
        Fuse chest displacement and motion intensity for better respiration signal
        """
        # Weight chest displacement more heavily than motion for respiration
        self.data['respiration_signal'] = (
            0.7 * self.data['chest_disp_norm'] + 
            0.3 * self.data['motion_intensity_norm']
        )
        
        return self.data
    
    def fuse_vital_signs(self):
        """Combine heart rate and SpO2 for vital sign assessment"""
        self.data['vital_sign_score'] = (
            0.5 * self.data['hr_bpm_norm'] + 
            0.5 * self.data['spo2']
        )
        
        return self.data
    
    def extract_respiratory_component(self, signal_column='chest_disp_smooth', 
                                      lowcut=0.1, highcut=1.0):
        """
        Extract respiratory frequency component using bandpass filter
        """
        # Handle NaN values
        if signal_column not in self.data.columns:
            signal_column = 'chest_disp'
        
        # Fill NaN values with 0 or interpolate
        signal_data = self.data[signal_column].fillna(0.0).values
        
        # Design Butterworth bandpass filter
        nyquist = SAMPLING_RATE / 2
        low = lowcut / nyquist
        high = highcut / nyquist
        
        # Ensure lowcut < highcut
        if low >= high:
            low = 0.05 / nyquist
            high = 0.99 / nyquist
        
        b, a = signal.butter(4, [low, high], btype='band')
        
        # Apply filter
        try:
            self.data['respiratory_component'] = signal.filtfilt(
                b, a, signal_data
            )
        except Exception as e:
            print(f"Warning: Error in filtfilt: {e}")
            self.data['respiratory_component'] = signal_data
        
        return self.data
    
    def calculate_motion_score(self):
        """Calculate overall motion score"""
        self.data['motion_score'] = np.abs(self.data['motion_intensity_smooth'])
        
        # Smooth motion score
        self.data['motion_score_smooth'] = self.data['motion_score'].rolling(
            window=5, center=True
        ).mean()
        
        return self.data
    
    def detect_presence_periods(self):
        """Identify continuous periods of presence"""
        self.data['presence_group'] = (
            self.data['presence'].diff().fillna(0) != 0
        ).astype(int).cumsum()
        
        return self.data

    def classify_state(self):
        """Classify EMPTY, LYING_STILL, MOVING, LEAVING from sensors"""
        self.data['motion_intensity_smooth'] = self.data['motion_intensity_smooth'].fillna(0)
        self.data['previous_presence'] = self.data['presence'].shift(1).fillna(0).astype(int)
        self.data['state'] = 'EMPTY'

        present = self.data['presence'] == 1
        still = self.data['motion_intensity_smooth'] <= MOTION_STILL_THRESHOLD
        moving = self.data['motion_intensity_smooth'] > MOTION_MOVING_THRESHOLD
        on_bed = self.data['loadcell_kg'] > EMPTY_WEIGHT_THRESHOLD
        leaving = (~present) & (self.data['previous_presence'] == 1) & (
            self.data['motion_intensity_smooth'] >= LEAVING_MOTION_THRESHOLD
        )

        self.data.loc[present & still, 'state'] = 'LYING_STILL'
        self.data.loc[present & moving, 'state'] = 'MOVING'
        self.data.loc[leaving, 'state'] = 'LEAVING'
        self.data.loc[~present & ~on_bed, 'state'] = 'EMPTY'

        self.data.drop(columns=['previous_presence'], inplace=True)
        return self.data
    
    def fuse_all_signals(self):
        """Execute complete sensor fusion"""
        print("Starting sensor fusion...")
        
        self.fuse_respiratory_signals()
        self.fuse_vital_signs()
        self.extract_respiratory_component()
        self.calculate_motion_score()
        self.detect_presence_periods()
        self.classify_state()
        
        print("Sensor fusion completed!")
        return self.data
    
    def get_data(self):
        """Return fused data"""
        return self.data


if __name__ == "__main__":
    from preprocessing import DataPreprocessor
    from config import DATA_PATH
    
    preprocessor = DataPreprocessor(DATA_PATH)
    data = preprocessor.preprocess()
    
    fusion = SensorFusion(data)
    fused_data = fusion.fuse_all_signals()
    print(fused_data.head())
