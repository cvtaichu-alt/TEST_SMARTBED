#!/usr/bin/env python3
"""
Main entry point for Smart Bed Sleep Apnea Detection System
Processes sensor data stream and generates output reports
"""

import sys
from pathlib import Path
import pandas as pd
import numpy as np
from datetime import datetime

# Add src to path
sys.path.insert(0, str(Path(__file__).parent))

from config import DATA_PATH, OUTPUT_DIR
from preprocessing import DataPreprocessor
from sensor_fusion import SensorFusion
from respiration import RespirationAnalysis
from apnea_detection import ApneaDetector
from visualization import DataVisualizer


def create_output_logger(data, respiration_data, apnea_events):
    """
    Create comprehensive output logs:
    1. Timeline: state + respiratory_rate + alerts
    2. Respiration: detailed respiration metrics
    3. Apnea events: event details
    """
    output_dir = Path(OUTPUT_DIR)
    output_dir.mkdir(exist_ok=True)
    
    # 1. Timeline log - state, respiratory rate, and alerts
    print("\n" + "="*70)
    print("TIMELINE LOG - State Transitions and Events")
    print("="*70)
    
    timeline_data = data[['timestamp_s', 'state', 'respiratory_rate', 
                          'hr_bpm', 'spo2', 'presence', 'loadcell_kg']].copy()
    timeline_data = timeline_data.round(3)
    
    # Add apnea alerts
    timeline_data['apnea_alert'] = ''
    for event in apnea_events:
        mask = (data['timestamp_s'] >= event['start_time']) & (data['timestamp_s'] <= event['end_time'])
        timeline_data.loc[mask, 'apnea_alert'] = f"APNEA: {event['duration_sec']:.1f}s"
    
    # Save timeline
    timeline_csv = output_dir / "timeline.csv"
    timeline_data.to_csv(timeline_csv, index=False)
    print(f"\nTimeline saved to: {timeline_csv}")
    print("\nFirst 20 rows of timeline:")
    print(timeline_data.head(20).to_string())
    
    # 2. Respiration log
    print("\n" + "="*70)
    print("RESPIRATION LOG")
    print("="*70)
    
    respiration_log = data[['timestamp_s', 'state', 'chest_disp', 'respiratory_component', 
                            'breathing_peak', 'breathing_trough', 'respiratory_rate']].copy()
    respiration_log = respiration_log.round(4)
    
    respiration_csv = output_dir / "respiration.csv"
    respiration_log.to_csv(respiration_csv, index=False)
    print(f"\nRespiration details saved to: {respiration_csv}")
    
    # Calculate statistics
    lying_still = respiration_log[respiration_log['state'] == 'LYING_STILL']
    if len(lying_still) > 0:
        avg_rr = lying_still['respiratory_rate'].mean()
        min_rr = lying_still['respiratory_rate'].min()
        max_rr = lying_still['respiratory_rate'].max()
        print(f"\nRespiratory Rate Statistics (LYING_STILL state):")
        print(f"  Average: {avg_rr:.2f} breaths/min")
        print(f"  Min: {min_rr:.2f} breaths/min")
        print(f"  Max: {max_rr:.2f} breaths/min")
    
    # 3. Apnea events log
    print("\n" + "="*70)
    print("APNEA EVENTS LOG")
    print("="*70)
    
    if len(apnea_events) > 0:
        apnea_df = pd.DataFrame(apnea_events)
        apnea_df = apnea_df[['start_time', 'end_time', 'duration_sec', 'avg_hr', 'min_spo2']]
        apnea_df = apnea_df.round(3)
        
        apnea_csv = output_dir / "apnea_events.csv"
        apnea_df.to_csv(apnea_csv, index=False)
        print(f"\nApnea events saved to: {apnea_csv}")
        print(f"\nTotal apnea events detected: {len(apnea_events)}")
        print("\nApnea Events Details:")
        print(apnea_df.to_string(index=False))
        
        # Apnea Index Calculation (simplified)
        total_lying_time = (data[data['state'] == 'LYING_STILL']['timestamp_s'].max() - 
                           data[data['state'] == 'LYING_STILL']['timestamp_s'].min()) / 60  # minutes
        apnea_index = (len(apnea_events) / total_lying_time * 60) if total_lying_time > 0 else 0
        print(f"\nApnea Index (AI): {apnea_index:.2f} events/hour")
    else:
        print("\nNo apnea events detected!")
        apnea_csv = output_dir / "apnea_events.csv"
        pd.DataFrame().to_csv(apnea_csv, index=False)
    
    # 4. Summary statistics
    print("\n" + "="*70)
    print("SUMMARY STATISTICS")
    print("="*70)
    
    state_counts = data['state'].value_counts()
    print("\nBed State Distribution:")
    for state, count in state_counts.items():
        percentage = (count / len(data)) * 100
        print(f"  {state}: {count} samples ({percentage:.1f}%)")
    
    # Heart rate stats
    valid_hr = data[data['hr_bpm'] > 0]['hr_bpm']
    if len(valid_hr) > 0:
        print(f"\nHeart Rate (valid samples):")
        print(f"  Average: {valid_hr.mean():.1f} bpm")
        print(f"  Min: {valid_hr.min():.1f} bpm")
        print(f"  Max: {valid_hr.max():.1f} bpm")
    
    # SpO2 stats
    print(f"\nBlood Oxygen Saturation (SpO2):")
    print(f"  Average: {data['spo2'].mean():.2f} %")
    print(f"  Min: {data['spo2'].min():.2f} %")
    print(f"  Max: {data['spo2'].max():.2f} %")
    
    print("\n" + "="*70 + "\n")
    
    return timeline_csv, respiration_csv, apnea_csv if len(apnea_events) > 0 else None


def main():
    """Main pipeline"""
    print("\n" + "="*70)
    print("SMART BED SLEEP APNEA DETECTION SYSTEM")
    print("="*70 + "\n")
    
    try:
        # 1. Load and preprocess data
        print("Step 1: Loading and preprocessing data...")
        preprocessor = DataPreprocessor(DATA_PATH)
        data = preprocessor.preprocess()
        
        if data is None:
            print("ERROR: Failed to load data!")
            return False
        
        # 2. Sensor fusion and state classification
        print("\nStep 2: Sensor fusion and state classification...")
        fusion = SensorFusion(data)
        data = fusion.fuse_all_signals()
        
        # 3. Respiration analysis
        print("\nStep 3: Respiration analysis...")
        respiration = RespirationAnalysis(data)
        data = respiration.analyze_respiration()
        
        # 4. Apnea detection
        print("\nStep 4: Apnea detection...")
        apnea_detector = ApneaDetector(data)
        data, apnea_events = apnea_detector.analyze_apnea()
        
        # 5. Create output logs
        print("\nStep 5: Generating output reports...")
        create_output_logger(data, respiration, apnea_events)
        
        # 6. Visualization
        print("\nStep 6: Creating visualizations...")
        visualizer = DataVisualizer(data, apnea_events, str(OUTPUT_DIR))
        visualizer.plot_vital_signs(OUTPUT_DIR / "vital_signs.png")
        visualizer.plot_respiration(OUTPUT_DIR / "respiration.png")
        visualizer.plot_apnea_events(OUTPUT_DIR / "apnea_detection.png")
        visualizer.create_dashboard(OUTPUT_DIR / "dashboard.png")
        
        print("\n" + "="*70)
        print("ANALYSIS COMPLETE!")
        print(f"Output files saved to: {OUTPUT_DIR}")
        print("="*70 + "\n")
        
        return True
        
    except Exception as e:
        print(f"\nERROR: {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
