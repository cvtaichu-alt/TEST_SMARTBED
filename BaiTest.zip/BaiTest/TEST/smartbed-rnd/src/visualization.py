"""
Visualization module for smartbed sensor analysis
"""

import matplotlib.pyplot as plt
import matplotlib.patches as patches
import numpy as np
import pandas as pd
from config import PLOT_FIGSIZE, PLOT_DPI


class DataVisualizer:
    """Handles visualization of sensor data and analysis results"""
    MAX_PLOT_POINTS = 1500
    
    def __init__(self, data, apnea_events=None, output_dir="../output"):
        """Initialize visualizer"""
        self.data = data
        self.apnea_events = apnea_events or []
        self.output_dir = output_dir
        
    def _downsample_series(self, x, y):
        """Downsample series for plotting to reduce memory use"""
        if len(x) <= self.MAX_PLOT_POINTS:
            return x, y
        step = max(1, len(x) // self.MAX_PLOT_POINTS)
        return x.iloc[::step], y.iloc[::step]

    def plot_vital_signs(self, save_path=None):
        """Plot vital signs (HR, SpO2)"""
        fig, axes = plt.subplots(2, 1, figsize=PLOT_FIGSIZE, dpi=PLOT_DPI)
        
        # Heart rate
        x, y = self._downsample_series(self.data['timestamp_s'], self.data['hr_bpm'])
        axes[0].plot(x, y, label='Heart Rate', color='red', linewidth=1.0)
        axes[0].axhline(y=60, color='green', linestyle='--', alpha=0.5, label='Normal range')
        axes[0].axhline(y=100, color='green', linestyle='--', alpha=0.5)
        axes[0].set_ylabel('Heart Rate (bpm)', fontsize=11)
        axes[0].set_title('Heart Rate Over Time', fontsize=12, fontweight='bold')
        axes[0].legend()
        axes[0].grid(True, alpha=0.3)
        
        # SpO2
        x, y = self._downsample_series(self.data['timestamp_s'], self.data['spo2'])
        axes[1].plot(x, y, label='SpO2', color='blue', linewidth=1.0)
        axes[1].axhline(y=95, color='green', linestyle='--', alpha=0.5, label='Normal threshold')
        axes[1].set_ylabel('SpO2 (%)', fontsize=11)
        axes[1].set_xlabel('Time (seconds)', fontsize=11)
        axes[1].set_title('Blood Oxygen Saturation Over Time', fontsize=12, fontweight='bold')
        axes[1].legend()
        axes[1].grid(True, alpha=0.3)
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=PLOT_DPI)
            print(f"Saved vital signs plot to {save_path}")
        
        return fig
    
    def plot_respiration(self, save_path=None):
        """Plot respiration signals"""
        fig, axes = plt.subplots(3, 1, figsize=PLOT_FIGSIZE, dpi=PLOT_DPI)
        
        # Raw chest displacement
        x_raw, y_raw = self._downsample_series(self.data['timestamp_s'], self.data['chest_disp'])
        x_smooth, y_smooth = self._downsample_series(self.data['timestamp_s'], self.data['chest_disp_smooth'])
        axes[0].plot(x_raw, y_raw, label='Raw', color='lightblue', linewidth=0.8, alpha=0.7)
        axes[0].plot(x_smooth, y_smooth, label='Smoothed', color='blue', linewidth=1.0)
        axes[0].set_ylabel('Chest Displacement (mm)', fontsize=11)
        axes[0].set_title('Chest Displacement (Raw vs Smoothed)', fontsize=12, fontweight='bold')
        axes[0].legend()
        axes[0].grid(True, alpha=0.3)
        
        # Filtered respiratory component
        x_resp, y_resp = self._downsample_series(self.data['timestamp_s'], self.data['respiratory_component'])
        axes[1].plot(x_resp, y_resp, color='green', linewidth=1.0)
        axes[1].scatter(self.data[self.data['breathing_peak'] == 1]['timestamp_s'],
                       self.data[self.data['breathing_peak'] == 1]['respiratory_component'],
                       color='red', s=50, marker='^', label='Inhalation peaks')
        axes[1].set_ylabel('Respiratory Signal (filtered)', fontsize=11)
        axes[1].set_title('Respiratory Signal with Detected Peaks', fontsize=12, fontweight='bold')
        axes[1].legend()
        axes[1].grid(True, alpha=0.3)
        
        # Breath amplitude
        x_amp, y_amp = self._downsample_series(self.data['timestamp_s'], self.data['breath_amplitude'])
        axes[2].plot(x_amp, y_amp, color='purple', linewidth=1.0)
        axes[2].set_ylabel('Breath Amplitude', fontsize=11)
        axes[2].set_xlabel('Time (seconds)', fontsize=11)
        axes[2].set_title('Breathing Amplitude Over Time', fontsize=12, fontweight='bold')
        axes[2].grid(True, alpha=0.3)
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=PLOT_DPI)
            print(f"Saved respiration plot to {save_path}")
        
        return fig
    
    def plot_apnea_detection(self, save_path=None):
        """Plot apnea events detection"""
        fig, axes = plt.subplots(3, 1, figsize=PLOT_FIGSIZE, dpi=PLOT_DPI)
        
        # Respiratory signal with apnea regions
        x_resp, y_resp = self._downsample_series(self.data['timestamp_s'], self.data['respiratory_component'])
        axes[0].plot(x_resp, y_resp, color='blue', linewidth=1.0, label='Respiratory signal')
        
        # Highlight apnea periods
        apnea_data = self.data[self.data['apnea_event'] == 1]
        if len(apnea_data) > 0:
            axes[0].scatter(apnea_data['timestamp_s'], apnea_data['respiratory_component'],
                          color='red', s=30, alpha=0.5, label='Apnea periods')
        
        axes[0].set_ylabel('Respiratory Signal', fontsize=11)
        axes[0].set_title('Apnea Detection - Respiratory Signal', fontsize=12, fontweight='bold')
        axes[0].legend()
        axes[0].grid(True, alpha=0.3)
        
        # SpO2 during apnea
        x_spo2, y_spo2 = self._downsample_series(self.data['timestamp_s'], self.data['spo2'])
        axes[1].plot(x_spo2, y_spo2, color='blue', linewidth=1.0, label='SpO2')
        axes[1].axhline(y=95, color='green', linestyle='--', alpha=0.5)
        
        low_spo2 = self.data[self.data['low_spo2'] == 1]
        if len(low_spo2) > 0:
            axes[1].scatter(low_spo2['timestamp_s'], low_spo2['spo2'],
                          color='orange', s=30, alpha=0.5, label='Low SpO2')
        
        axes[1].set_ylabel('SpO2 (%)', fontsize=11)
        axes[1].set_title('Blood Oxygen Levels', fontsize=12, fontweight='bold')
        axes[1].legend()
        axes[1].grid(True, alpha=0.3)
        
        # Heart rate during apnea
        x_hr, y_hr = self._downsample_series(self.data['timestamp_s'], self.data['hr_bpm'])
        axes[2].plot(x_hr, y_hr, color='red', linewidth=1.0, label='Heart Rate')
        
        bradycardia = self.data[self.data['bradycardia'] == 1]
        if len(bradycardia) > 0:
            axes[2].scatter(bradycardia['timestamp_s'], bradycardia['hr_bpm'],
                          color='darkred', s=30, alpha=0.5, label='Bradycardia')
        
        axes[2].set_ylabel('Heart Rate (bpm)', fontsize=11)
        axes[2].set_xlabel('Time (seconds)', fontsize=11)
        axes[2].set_title('Heart Rate Response', fontsize=12, fontweight='bold')
        axes[2].legend()
        axes[2].grid(True, alpha=0.3)
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=PLOT_DPI)
            print(f"Saved apnea detection plot to {save_path}")
        
        return fig
    
    def plot_apnea_events(self, save_path=None):
        """Plot apnea events with timeline and details"""
        fig, axes = plt.subplots(3, 1, figsize=PLOT_FIGSIZE, dpi=PLOT_DPI)
        
        # Mark apnea events in data
        self.data['apnea_event'] = 0
        for event in self.apnea_events:
            mask = (self.data['timestamp_s'] >= event['start_time']) & (self.data['timestamp_s'] <= event['end_time'])
            self.data.loc[mask, 'apnea_event'] = 1
        
        # Respiratory signal with apnea regions
        x_resp, y_resp = self._downsample_series(self.data['timestamp_s'], self.data['respiratory_component'])
        axes[0].plot(x_resp, y_resp, color='blue', linewidth=1.0, label='Respiratory signal')
        
        # Highlight apnea periods
        apnea_data = self.data[self.data['apnea_event'] == 1]
        if len(apnea_data) > 0:
            axes[0].scatter(apnea_data['timestamp_s'], apnea_data['respiratory_component'],
                          color='red', s=30, alpha=0.5, label='Apnea periods')
        
        axes[0].set_ylabel('Respiratory Signal', fontsize=11)
        axes[0].set_title('Apnea Detection - Respiratory Signal', fontsize=12, fontweight='bold')
        axes[0].legend()
        axes[0].grid(True, alpha=0.3)
        
        # SpO2 during apnea
        x_spo2, y_spo2 = self._downsample_series(self.data['timestamp_s'], self.data['spo2'])
        axes[1].plot(x_spo2, y_spo2, color='blue', linewidth=1.0, label='SpO2')
        axes[1].axhline(y=95, color='green', linestyle='--', alpha=0.5)
        
        low_spo2 = self.data[self.data['low_spo2'] == 1]
        if len(low_spo2) > 0:
            axes[1].scatter(low_spo2['timestamp_s'], low_spo2['spo2'],
                          color='orange', s=30, alpha=0.5, label='Low SpO2')
        
        axes[1].set_ylabel('SpO2 (%)', fontsize=11)
        axes[1].set_title('Blood Oxygen Levels', fontsize=12, fontweight='bold')
        axes[1].legend()
        axes[1].grid(True, alpha=0.3)
        
        # Heart rate during apnea
        x_hr, y_hr = self._downsample_series(self.data['timestamp_s'], self.data['hr_bpm'])
        axes[2].plot(x_hr, y_hr, color='red', linewidth=1.0, label='Heart Rate')
        
        bradycardia = self.data[self.data['bradycardia'] == 1]
        if len(bradycardia) > 0:
            axes[2].scatter(bradycardia['timestamp_s'], bradycardia['hr_bpm'],
                          color='darkred', s=30, alpha=0.5, label='Bradycardia')
        
        axes[2].set_ylabel('Heart Rate (bpm)', fontsize=11)
        axes[2].set_xlabel('Time (seconds)', fontsize=11)
        axes[2].set_title('Heart Rate Response', fontsize=12, fontweight='bold')
        axes[2].legend()
        axes[2].grid(True, alpha=0.3)
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=PLOT_DPI)
            print(f"Saved apnea events plot to {save_path}")
        
        return fig
    def create_dashboard(self, save_path=None):
        """Create comprehensive dashboard"""
        fig = plt.figure(figsize=(16, 12), dpi=PLOT_DPI)
        gs = fig.add_gridspec(4, 2, hspace=0.3, wspace=0.3)
        
        # Title
        fig.suptitle('Smart Bed Sensor Analysis Dashboard', fontsize=16, fontweight='bold', y=0.995)
        
        # 1. Vital signs
        ax1 = fig.add_subplot(gs[0, 0])
        x_hr, y_hr = self._downsample_series(self.data['timestamp_s'], self.data['hr_bpm'])
        ax1.plot(x_hr, y_hr, color='red', linewidth=1.0)
        ax1.set_ylabel('HR (bpm)', fontsize=10)
        ax1.set_title('Heart Rate', fontsize=11, fontweight='bold')
        ax1.grid(True, alpha=0.3)
        
        # 2. SpO2
        ax2 = fig.add_subplot(gs[0, 1])
        x_spo2, y_spo2 = self._downsample_series(self.data['timestamp_s'], self.data['spo2'])
        ax2.plot(x_spo2, y_spo2, color='blue', linewidth=1.0)
        ax2.axhline(y=95, color='green', linestyle='--', alpha=0.5)
        ax2.set_ylabel('SpO2 (%)', fontsize=10)
        ax2.set_title('Blood Oxygen', fontsize=11, fontweight='bold')
        ax2.grid(True, alpha=0.3)
        
        # 3. Respiratory signal
        ax3 = fig.add_subplot(gs[1, :])
        x_resp, y_resp = self._downsample_series(self.data['timestamp_s'], self.data['respiratory_component'])
        ax3.plot(x_resp, y_resp, color='green', linewidth=1.0, label='Respiratory signal')
        ax3.scatter(self.data[self.data['apnea_event'] == 1]['timestamp_s'],
                   self.data[self.data['apnea_event'] == 1]['respiratory_component'],
                   color='red', s=20, alpha=0.6, label='Apnea events')
        ax3.set_ylabel('Signal', fontsize=10)
        ax3.set_title('Respiratory Analysis with Apnea Events', fontsize=11, fontweight='bold')
        ax3.legend(loc='upper right')
        ax3.grid(True, alpha=0.3)
        
        # 4. Chest displacement
        ax4 = fig.add_subplot(gs[2, 0])
        x_chest, y_chest = self._downsample_series(self.data['timestamp_s'], self.data['chest_disp_smooth'])
        ax4.plot(x_chest, y_chest, color='purple', linewidth=1.0)
        ax4.set_ylabel('Displacement (mm)', fontsize=10)
        ax4.set_title('Chest Displacement', fontsize=11, fontweight='bold')
        ax4.grid(True, alpha=0.3)
        
        # 5. Motion intensity
        ax5 = fig.add_subplot(gs[2, 1])
        x_motion, y_motion = self._downsample_series(self.data['timestamp_s'], self.data['motion_intensity_smooth'])
        ax5.plot(x_motion, y_motion, color='orange', linewidth=1.0)
        ax5.set_ylabel('Intensity', fontsize=10)
        ax5.set_title('Motion Intensity', fontsize=11, fontweight='bold')
        ax5.grid(True, alpha=0.3)
        
        # 6. Statistics
        ax6 = fig.add_subplot(gs[3, :])
        ax6.axis('off')
        
        # Calculate statistics
        stats_text = self._generate_statistics_text()
        ax6.text(0.05, 0.95, stats_text, transform=ax6.transAxes,
                fontsize=10, verticalalignment='top', fontfamily='monospace',
                bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))
        
        if save_path:
            plt.savefig(save_path, dpi=PLOT_DPI, bbox_inches='tight')
            print(f"Saved dashboard to {save_path}")
        
        return fig
    
    def _generate_statistics_text(self):
        """Generate statistics text for dashboard"""
        hr_mean = self.data['hr_bpm'].mean()
        hr_std = self.data['hr_bpm'].std()
        spo2_mean = self.data['spo2'].mean()
        spo2_min = self.data['spo2'].min()
        
        breathing_peaks = (self.data['breathing_peak'] == 1).sum()
        apnea_count = len(self.apnea_events)
        
        total_duration = self.data['timestamp_s'].max() - self.data['timestamp_s'].min()
        ahi = apnea_count / (total_duration / 3600) if total_duration > 0 else 0
        
        stats = f"""
VITAL SIGNS SUMMARY
─────────────────────────────────────
Heart Rate:        {hr_mean:6.1f} ± {hr_std:5.1f} bpm
SpO2 Mean:         {spo2_mean:6.1f} %
SpO2 Minimum:      {spo2_min:6.1f} %

RESPIRATORY ANALYSIS
─────────────────────────────────────
Breathing Cycles Detected:  {breathing_peaks:5d}
Average RR:                 {self.data['respiratory_rate'].iloc[-1]:5.1f} breaths/min

APNEA ANALYSIS
─────────────────────────────────────
Total Apnea Events:         {apnea_count:5d}
Apnea-Hypopnea Index (AHI):  {ahi:5.2f} events/hour
Recording Duration:         {total_duration:6.1f} seconds
"""
        
        return stats
    
    def show_all_plots(self):
        """Display all plots"""
        self.plot_vital_signs()
        self.plot_respiration()
        self.plot_apnea_detection()
        self.create_dashboard()
        plt.show()
    
    def save_all_plots(self):
        """Save all plots to output directory"""
        fig = self.plot_vital_signs(f"{self.output_dir}/vital_signs.png")
        plt.close(fig)
        fig = self.plot_respiration(f"{self.output_dir}/respiration.png")
        plt.close(fig)
        fig = self.plot_apnea_detection(f"{self.output_dir}/apnea_detection.png")
        plt.close(fig)
        fig = self.create_dashboard(f"{self.output_dir}/dashboard.png")
        plt.close(fig)


if __name__ == "__main__":
    from preprocessing import DataPreprocessor
    from sensor_fusion import SensorFusion
    from respiration import RespirationAnalysis
    from apnea_detection import ApneaDetector
    from config import DATA_PATH
    
    preprocessor = DataPreprocessor(DATA_PATH)
    data = preprocessor.preprocess()
    
    fusion = SensorFusion(data)
    data = fusion.fuse_all_signals()
    
    respiration = RespirationAnalysis(data)
    data = respiration.analyze_respiration()
    
    apnea = ApneaDetector(data)
    data = apnea.detect_apnea()
    
    visualizer = DataVisualizer(data, apnea.get_apnea_events())
    visualizer.save_all_plots()
    visualizer.show_all_plots()
