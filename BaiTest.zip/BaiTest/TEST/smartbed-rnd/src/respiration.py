"""
Respiration detection and analysis module
"""

import numpy as np
import pandas as pd
from scipy import signal
from scipy.signal import find_peaks
from config import SAMPLING_RATE, BREATHING_RATE_THRESHOLD, RRV_WINDOW


class RespirationAnalysis:
    """Analyzes respiratory patterns from sensor data"""
    
    def __init__(self, data):
        """Initialize with fused sensor data"""
        self.data = data.copy()
        self.breathing_cycles = []
        self.respiratory_rate = 0.0
        
    def detect_breathing_peaks(self, signal_column='respiratory_component', 
                               prominence=0.1, distance=None):
        """
        Detect peaks in respiratory signal, only when lying still
        """
        if distance is None:
            distance = SAMPLING_RATE * 1.5  # Minimum 1.5 seconds between breaths
        
        self.data['breathing_peak'] = 0
        self.data['breathing_trough'] = 0
        
        still_mask = self.data['state'] == 'LYING_STILL'
        if still_mask.sum() < 2:
            return self.data, np.array([], dtype=int), np.array([], dtype=int)
        
        valid_positions = np.flatnonzero(still_mask.values)
        signal_data = self.data.loc[still_mask, signal_column].values
        
        # Find peaks (inhalation)
        peaks, _ = find_peaks(
            signal_data,
            prominence=prominence,
            distance=distance
        )
        
        # Find troughs (exhalation)
        troughs, _ = find_peaks(
            -signal_data,
            prominence=prominence,
            distance=distance
        )
        
        peak_positions = valid_positions[peaks] if len(peaks) > 0 else np.array([], dtype=int)
        trough_positions = valid_positions[troughs] if len(troughs) > 0 else np.array([], dtype=int)
        
        self.data.loc[peak_positions, 'breathing_peak'] = 1
        self.data.loc[trough_positions, 'breathing_trough'] = 1
        
        return self.data, peak_positions, trough_positions
    
    def calculate_respiratory_rate_windowed(self, window_seconds=30):
        """
        Calculate breathing rate using sliding window from chest_disp
        Only when state is LYING_STILL
        """
        window_samples = int(window_seconds * SAMPLING_RATE)
        self.data['respiratory_rate'] = 0.0
        
        for i in range(len(self.data) - window_samples):
            window_data = self.data.iloc[i:i+window_samples]
            
            # Only calculate if state is LYING_STILL in this window
            if (window_data['state'] == 'LYING_STILL').sum() < window_samples * 0.8:
                continue
            
            # Find peaks in respiratory component for this window
            signal_window = window_data['respiratory_component'].values
            
            # Find peaks with dynamic prominence based on signal amplitude
            signal_std = np.std(signal_window)
            prominence_threshold = max(0.05, signal_std * 0.5)
            
            peaks, _ = find_peaks(
                signal_window,
                prominence=prominence_threshold,
                distance=SAMPLING_RATE * 1.2  # At least 1.2 seconds between breaths
            )
            
            if len(peaks) >= 2:
                # Calculate breathing rate from peak intervals
                peak_times = window_data['timestamp_s'].iloc[peaks].values
                time_diffs = np.diff(peak_times)
                avg_period = np.mean(time_diffs)
                respiratory_rate = 60.0 / avg_period if avg_period > 0 else 0
                
                # Validate rate (reasonable range: 8-30 breaths/min)
                if 8 <= respiratory_rate <= 30:
                    self.data.loc[i+window_samples-1, 'respiratory_rate'] = respiratory_rate
        
        # Fill missing values with forward fill then backward fill
        self.data['respiratory_rate'] = self.data['respiratory_rate'].replace(0.0, np.nan)
        self.data['respiratory_rate'] = self.data['respiratory_rate'].ffill().bfill()
        self.data['respiratory_rate'] = self.data['respiratory_rate'].fillna(0.0)
        
        return self.data
    
    def calculate_breath_amplitude(self, peaks, troughs):
        """Calculate respiratory amplitude"""
        if len(peaks) == 0 or len(troughs) == 0:
            self.data['breath_amplitude'] = 0.0
            return self.data
        
        signal_data = self.data['respiratory_component'].values
        
        self.data['breath_amplitude'] = 0.0
        for i, peak_idx in enumerate(peaks):
            # Find nearest trough
            nearest_trough = troughs[np.argmin(np.abs(troughs - peak_idx))]
            amplitude = abs(signal_data[peak_idx] - signal_data[nearest_trough])
            self.data.loc[peak_idx, 'breath_amplitude'] = amplitude
        
        return self.data
    
    def calculate_respiratory_variability(self, window_seconds=RRV_WINDOW):
        """
        Calculate respiratory rate variability (RRV)
        """
        window_samples = int(window_seconds * SAMPLING_RATE)
        
        self.data['rrv'] = 0.0
        
        for i in range(len(self.data) - window_samples):
            window_data = self.data.iloc[i:i+window_samples]
            peaks_in_window = np.where(window_data['breathing_peak'] == 1)[0]
            
            if len(peaks_in_window) > 1:
                peak_times = window_data['timestamp_s'].iloc[peaks_in_window].values
                time_diffs = np.diff(peak_times)
                rrv = np.std(time_diffs) if len(time_diffs) > 1 else 0
                self.data.loc[i+window_samples, 'rrv'] = rrv
        
        self.data['rrv'] = self.data['rrv'].bfill()
        
        return self.data
    
    def detect_irregular_breathing(self, amplitude_threshold=0.2, 
                                   rate_threshold=BREATHING_RATE_THRESHOLD):
        """Detect irregular breathing patterns"""
        self.data['irregular_breathing'] = 0
        
        # Low amplitude
        self.data.loc[self.data['breath_amplitude'] < amplitude_threshold, 
                     'irregular_breathing'] = 1
        
        # Abnormal rate will be detected in apnea_detection module
        
        return self.data
    
    def analyze_respiration(self):
        """Execute complete respiration analysis"""
        print("Starting respiration analysis...")
        
        # Detect breathing cycles
        self.data, peaks, troughs = self.detect_breathing_peaks()
        
        # Calculate metrics using sliding window
        self.calculate_respiratory_rate_windowed(window_seconds=30)
        self.calculate_breath_amplitude(peaks, troughs)
        self.calculate_respiratory_variability()
        self.detect_irregular_breathing()
        
        # Calculate average respiratory rate for lying still periods
        lying_still_data = self.data[self.data['state'] == 'LYING_STILL']
        avg_rr = lying_still_data['respiratory_rate'].mean() if len(lying_still_data) > 0 else 0
        
        print(f"Respiration analysis completed!")
        print(f"Average respiratory rate (lying still): {float(avg_rr):.2f} breaths/min")
        
        return self.data
    
    def get_data(self):
        """Return analyzed data"""
        return self.data


if __name__ == "__main__":
    from preprocessing import DataPreprocessor
    from sensor_fusion import SensorFusion
    from config import DATA_PATH
    
    preprocessor = DataPreprocessor(DATA_PATH)
    data = preprocessor.preprocess()
    
    fusion = SensorFusion(data)
    data = fusion.fuse_all_signals()
    
    respiration = RespirationAnalysis(data)
    data = respiration.analyze_respiration()
    print(data[['timestamp_s', 'breathing_peak', 'breath_amplitude', 'estimated_rr']].head(20))
