"""
Configuration file for Smart Bed RND Project
"""

from pathlib import Path

# Base directory for the project (one level above src)
BASE_DIR = Path(__file__).resolve().parent.parent

# Data paths
DATA_PATH = BASE_DIR / "data" / "smartbed-sensor-stream.csv"
OUTPUT_DIR = BASE_DIR / "output"

# Sensor parameters
SAMPLING_RATE = 10  # Hz (10 samples per second based on 0.1s intervals)
CHEST_DISPLACEMENT_THRESHOLD = 0.5  # mm, threshold for respiratory motion
HR_NORMAL_RANGE = (60, 100)  # bpm, normal heart rate range
SPO2_NORMAL_THRESHOLD = 95  # %, normal SpO2 level

# State classification
EMPTY_WEIGHT_THRESHOLD = 10  # kg, below this is considered empty bed
MOTION_STILL_THRESHOLD = 0.1  # motion intensity threshold for lying still
MOTION_MOVING_THRESHOLD = 0.3  # motion intensity threshold for moving
LEAVING_MOTION_THRESHOLD = 0.15  # motion intensity threshold used to flag leaving transitions

# Apnea detection parameters
APNEA_DURATION_THRESHOLD = 10  # seconds, minimum duration to classify as apnea
BREATHING_RATE_THRESHOLD = 8  # breaths per minute, below this is abnormal
CHEST_MOTION_THRESHOLD = 0.1  # mm, minimum chest displacement for breathing to detect apnea
APNEA_AMPLITUDE_THRESHOLD = 0.05  # mm, threshold to detect breath cessation
RRV_WINDOW = 30  # seconds, respiratory rate variability window

# Preprocessing parameters
SMOOTHING_WINDOW = 5  # samples, window for moving average
OUTLIER_THRESHOLD = 3  # standard deviations for outlier detection

# Output settings
CSV_DECIMAL_PLACES = 3
PLOT_DPI = 80
PLOT_FIGSIZE = (8, 5)

# Algorithm parameters
RESPIRATION_MIN_FREQUENCY = 0.1  # Hz (0.6 breaths/min minimum)
RESPIRATION_MAX_FREQUENCY = 1.0  # Hz (60 breaths/min maximum)
