"""
Apnea detection and analysis module
"""

import numpy as np
import pandas as pd
from scipy.signal import find_peaks
from config import (
    SAMPLING_RATE, APNEA_DURATION_THRESHOLD, CHEST_MOTION_THRESHOLD,
    SPO2_NORMAL_THRESHOLD, HR_NORMAL_RANGE
)


class ApneaDetector:
    """Detects and classifies apnea events"""
    
    def __init__(self, data):
        """Initialize with respiration analysis data"""
        self.data = data.copy()
        self.apnea_events = []
        
    def detect_breath_cessation(self, signal_column='respiratory_component',
                               amplitude_threshold=None,
                               duration_threshold=APNEA_DURATION_THRESHOLD):
        """
        Detect periods of breath cessation - when chest displacement is minimal
        Only when person is present and lying still
        """
        from config import APNEA_AMPLITUDE_THRESHOLD
        
        if amplitude_threshold is None:
            amplitude_threshold = APNEA_AMPLITUDE_THRESHOLD
        
        signal_data = self.data[signal_column].values
        signal_abs = np.abs(signal_data)
        
        # Identify low respiratory signal only when person is present and lying still
        low_activity = (
            (signal_abs < amplitude_threshold) &
            (self.data['presence'] == 1) &
            (self.data['state'] == 'LYING_STILL')
        )
        
        self.data['low_respiratory_activity'] = low_activity.astype(int)
        
        # Find continuous low activity periods
        breath_cessation_groups = self._identify_continuous_periods(
            low_activity, 
            min_duration=duration_threshold * SAMPLING_RATE
        )
        
        return breath_cessation_groups
    
    def _identify_continuous_periods(self, binary_signal, min_duration):
        """Identify continuous periods in binary signal"""
        periods = []
        
        in_event = False
        start_idx = 0
        
        for i, val in enumerate(binary_signal):
            if val and not in_event:
                # Event starts
                in_event = True
                start_idx = i
            elif not val and in_event:
                # Event ends
                duration = i - start_idx
                if duration >= min_duration:
                    periods.append((start_idx, i, duration / SAMPLING_RATE))
                in_event = False
        
        # Handle event at end of data
        if in_event:
            duration = len(binary_signal) - start_idx
            if duration >= min_duration:
                periods.append((start_idx, len(binary_signal), duration / SAMPLING_RATE))
        
        return periods
    
    def detect_hypoxia(self, spo2_threshold=SPO2_NORMAL_THRESHOLD,
                      duration_threshold=5):
        """Detect periods of low blood oxygen saturation"""
        low_spo2 = self.data['spo2'] < spo2_threshold
        
        self.data['low_spo2'] = low_spo2.astype(int)
        
        hypoxia_periods = self._identify_continuous_periods(
            low_spo2.values,
            min_duration=duration_threshold * SAMPLING_RATE
        )
        
        return hypoxia_periods
    
    def detect_bradycardia(self, hr_min=40, duration_threshold=5):
        """Detect periods of abnormally low heart rate"""
        low_hr = self.data['hr_bpm'] < hr_min
        
        self.data['bradycardia'] = low_hr.astype(int)
        
        bradycardia_periods = self._identify_continuous_periods(
            low_hr.values,
            min_duration=duration_threshold * SAMPLING_RATE
        )
        
        return bradycardia_periods
    
    def extract_apnea_events(self, breath_cessation_periods):
        """
        Extract apnea events with timestamps and details
        """
        self.apnea_events = []
        
        for start_idx, end_idx, duration_sec in breath_cessation_periods:
            event = {
                'start_time': float(self.data.iloc[start_idx]['timestamp_s']),
                'end_time': float(self.data.iloc[end_idx-1]['timestamp_s']),
                'duration_sec': float(duration_sec),
                'start_idx': start_idx,
                'end_idx': end_idx,
                'avg_hr': float(self.data.iloc[start_idx:end_idx]['hr_bpm'].mean()),
                'min_spo2': float(self.data.iloc[start_idx:end_idx]['spo2'].min()),
            }
            self.apnea_events.append(event)
        
        return self.apnea_events
    
    def analyze_apnea(self):
        """Execute complete apnea detection"""
        print("Starting apnea detection...")
        
        # Detect breath cessation
        breath_cessation_periods = self.detect_breath_cessation()
        
        # Extract apnea events
        self.extract_apnea_events(breath_cessation_periods)
        
        # Detect hypoxia
        hypoxia_periods = self.detect_hypoxia()
        
        # Detect bradycardia
        bradycardia_periods = self.detect_bradycardia()
        
        print(f"Apnea analysis completed!")
        print(f"Found {len(self.apnea_events)} apnea events")
        
        return self.data, self.apnea_events
    
    def get_apnea_events(self):
        """Return list of apnea events"""
        return self.apnea_events
    
    def classify_apnea_events(self, cessation_periods, hypoxia_periods, 
                             bradycardia_periods):
        """
        Classify apnea events and correlate with vital signs
        """
        self.data['apnea_event'] = 0
        self.data['apnea_type'] = 'None'
        
        for start, end, duration in cessation_periods:
            # Check for hypoxia or bradycardia during apnea
            hypoxia_overlap = self._check_period_overlap(
                (start, end), hypoxia_periods
            )
            bradycardia_overlap = self._check_period_overlap(
                (start, end), bradycardia_periods
            )
            
            # Classify apnea type
            if hypoxia_overlap:
                apnea_type = 'Central'  # Associated with reduced oxygen
            elif bradycardia_overlap:
                apnea_type = 'Obstructive'  # Associated with cardiac effect
            else:
                apnea_type = 'Mixed'
            
            # Mark apnea in data
            self.data.loc[start:end, 'apnea_event'] = 1
            self.data.loc[start:end, 'apnea_type'] = apnea_type
            
            # Record event
            self.apnea_events.append({
                'start_idx': start,
                'end_idx': end,
                'start_time': self.data['timestamp_s'].iloc[start],
                'end_time': self.data['timestamp_s'].iloc[end],
                'duration_s': duration,
                'type': apnea_type,
                'hypoxia': hypoxia_overlap,
                'bradycardia': bradycardia_overlap
            })
        
        return self.data
    
    def _check_period_overlap(self, period1, periods_list):
        """Check if period1 overlaps with any period in periods_list"""
        start1, end1 = period1
        
        for start2, end2, _ in periods_list:
            if not (end1 < start2 or start1 > end2):
                return True
        
        return False
    
    def calculate_apnea_index(self):
        """Calculate Apnea-Hypopnea Index (AHI)"""
        if len(self.data) == 0:
            return 0
        
        # Calculate sleep duration in hours
        total_duration_s = self.data['timestamp_s'].max() - self.data['timestamp_s'].min()
        sleep_duration_h = total_duration_s / 3600
        
        if sleep_duration_h == 0:
            return 0
        
        # AHI = number of apnea events per hour
        ahi = len(self.apnea_events) / sleep_duration_h
        
        return ahi
    
    def detect_apnea(self):
        """Execute complete apnea detection"""
        print("Starting apnea detection...")
        
        # Detect breath cessation
        cessation_periods = self.detect_breath_cessation()
        print(f"Found {len(cessation_periods)} breath cessation periods")
        
        # Detect hypoxia
        hypoxia_periods = self.detect_hypoxia()
        print(f"Found {len(hypoxia_periods)} hypoxia periods")
        
        # Detect bradycardia
        bradycardia_periods = self.detect_bradycardia()
        print(f"Found {len(bradycardia_periods)} bradycardia periods")
        
        # Classify events
        self.classify_apnea_events(cessation_periods, hypoxia_periods, 
                                  bradycardia_periods)
        
        # Calculate AHI
        ahi = self.calculate_apnea_index()
        
        print(f"Apnea detection completed!")
        print(f"Total apnea events detected: {len(self.apnea_events)}")
        print(f"Apnea-Hypopnea Index (AHI): {ahi:.2f} events/hour")
        
        return self.data
    
    def get_data(self):
        """Return data with apnea annotations"""
        return self.data
    
    def get_apnea_events(self):
        """Return list of detected apnea events"""
        return self.apnea_events


if __name__ == "__main__":
    from preprocessing import DataPreprocessor
    from sensor_fusion import SensorFusion
    from respiration import RespirationAnalysis
    from config import DATA_PATH
    
    preprocessor = DataPreprocessor(DATA_PATH)
    data = preprocessor.preprocess()
    
    fusion = SensorFusion(data)
    data = fusion.fuse_all_signals()
    
    respiration = RespirationAnalysis(data)
    data = respiration.analyze_respiration()
    
    apnea = ApneaDetector(data)
    data = apnea.detect_apnea()
    
    events = apnea.get_apnea_events()
    print(f"\nApnea Events Summary:")
    for event in events:
        print(f"  Time: {event['start_time']:.1f}s - {event['end_time']:.1f}s, "
              f"Duration: {event['duration_s']:.1f}s, Type: {event['type']}")
